def echo_test():
    print("echo")
    
