# DemoPackage.demo2.py
def func1():
    print("DemoPackage.demo2.func1()")
    
def func2():
    print("DemoPackage.demo2.func2()")
    
